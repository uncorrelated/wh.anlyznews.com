loadLib <- function(...){
    for(lname in unlist(list(...))){
        if(!any(suppressWarnings(library(quietly=TRUE, verbose=FALSE)$results[,"Package"] == lname))){
            stop(sprintf("Do install.packages(\"%s\") before runnning this script.", lname))
        }
        library(lname, character.only = TRUE)
    }
}

