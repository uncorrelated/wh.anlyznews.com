source("loadLib.R")
source("EdgeworthBox.R")

loadLib("nleqslv", "shiny")

ui <- fluidPage(
    # theme = bslib::bs_theme(bootswatch = "minty"),
    titlePanel("Edgeworth Box"),

    fluidRow(
        column(3, 
            sliderInput("A",
                "initial amount of goods A of person 1",
                min = 0.01,
                max = 0.99,
                value = 0.8), 
            sliderInput("B",
                "initial amount of goods B of person 1",
                min = 0.01,
                max = 0.99,
                value = 0.3),
            checkboxInput("isIP", "Initial Point", TRUE),
            checkboxInput("isIC_I", "Indiffrent Curves pass through the Initial Point", TRUE),
            # チェックボックスありとなしの見えないタブを作る
            tabsetPanel(
                id = "tab4core",
                type = "hidden",
                tabPanel("true",
                    checkboxInput("isCore", "Core", TRUE)
                ),
                tabPanel("false")
            ),
            checkboxInput("isIC_E", "Indiffrent Curves pass through the Equilibrium", TRUE),
            checkboxInput("isSHP", "Separating Hyperplane", TRUE),
            checkboxInput("isCC", "Contract Curve", TRUE)
        ),
        column(4, 
            plotOutput("distPlot"),
        ),
        column(3, 
            sliderInput("angle",
                "angle of rotation",
                min = -180,
                max = 0,
                value = 0,
                width = "50%"),
            checkboxInput("prsn1", "Show properties of Person 1", TRUE),
            checkboxInput("prsn2", "Show properties of Person 2", TRUE)
        )
    )
)

server <- function(input, output) {
    # input$isIC_Iが変更されたら、見えないタブを切り替える
    observeEvent(input$isIC_I, {
        updateTabsetPanel(inputId = "tab4core", selected = ifelse(input$isIC_I, "true", "false"))
    })

    output$distPlot <- renderPlot({
        # inputはReactiveValuesクラスで$で参照できる変数を陽に持たないため、withやattachが使えない
        drawEdgeworthBox(input$A, input$B, CC=input$isCC, SHP=input$isSHP, IC_I=input$isIC_I,
            IC_E=input$isIC_E, CORE=input$isCore, IP=input$isIP, angle=input$angle/180*pi, prsn1=input$prsn1, prsn2=input$prsn2)
    }, width=500, height=500)
}

app <- shinyApp(ui = ui, server = server)
runApp(app)

