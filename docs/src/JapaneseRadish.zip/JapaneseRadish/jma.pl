#!/usr/bin/perl
use strict;
use warnings;
use LWP::UserAgent;
use Encode;

my $ua = LWP::UserAgent->new(agent => "Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)");

my ($input, $rainfall, $temperature, $insolation);
my $dir = ".";
open($rainfall, ">$dir/rainfall.txt") || die "$!";
open($temperature, ">$dir/temperature.txt") || die "$!";
open($insolation, ">$dir/insolation.txt") || die "$!";
open($input, "$dir/jma.lst") || die "$!";

my $header = encode("utf8", decode("utf8", "pref_id\tpref_name\tblock_id\tblock_name\t年\t1月\t2月\t3月\t4月\t5月\t6月\t7月\t8月\t9月\t10月\t11月\t12月\t年平均\n"));
print $rainfall  $header;
print $temperature $header;
print $insolation $header;

my $skip_word = decode("utf8","年");
my $erase_word = decode("utf8","[×　]");

while(my $line = decode("sjis", <$input>)){
	$line =~ s/[\n\r]+//g;
	my $pref_no = $1 if($line =~ m/prec_no=([0-9]+)/);
	my $pref_name = $1 if($line =~ m/^([^\t]+)\t/);
	my $block_no = $1 if($line =~ m/block_no=([0-9]+)/);
	my %type = ("a1"=>[decode("utf8","気温"), $temperature], "a12"=>[decode("utf8","日照時間"), $insolation], "a13"=>[decode("utf8","降水量"), $rainfall]);
	foreach my $key (keys(%type)){
		my $url = "http://www.data.jma.go.jp/obd/stats/etrn/view/monthly_s3.php?block_no=$block_no&view=$key";
		my $content = decode("sjis", $ua->get($url)->content);
		my $block_name = "";
		if($content =~ m/<table[ \t]+class="data2_s"[ \t]+summary="([^"]+)">/){
			$block_name = $1;
		}
		$content =~ s/^.*<table[ \t]+class="data2_s"[^>]*>//s;
		my $endstring = "</table>";
		$content = substr($content, 0, index($content, $endstring));
		$content =~ s/<caption[^>]*>.*<\/caption>[\n\r]*//s;
		$content =~ s/<\/?tr[^>]*>//g;
		$content =~ s/<\/th>/\t/g;
		$content =~ s/<\/td>/\t/g;
		$content =~ s/<[^>]*>//g;
		$content =~ s/\t+$//g;
		$content =~ s/\]//g;
		$content =~ s/\)//g;
		$content =~ s/\t\t*/\t/g;
		my @data = split(/[\n\r]+/, $content);
		my @r;
		my $a = $type{$key};
		foreach my $data (@data){
			next if($data =~ m/${skip_word}/);
			$data =~ s/${erase_word}//g;
			$data =~ s/\t$//;
			push(@r, sprintf("%s\t%s\t%s\t%s\t%s",$pref_no,$pref_name,$block_no,$block_name,$data));
		}
		my $stream = $$a[1];
		print $stream encode("utf8", join("\n", @r)),"\n";
	}
}

close($input);
close($rainfall);
close($temperature);
close($insolation);
