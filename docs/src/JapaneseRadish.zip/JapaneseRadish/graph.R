# テキスト・ファイルからデータを読み込む
df <- read.table("dataset.txt", header=TRUE, sep="\t", fileEncoding="UTF-8")

# 2009年に絞ったデータセットを作成
tyear <- 2009
df09 <- subset(df, 年==tyear)

# PNGファイルを作成
zoom <- 640/297
png(file=sprintf("japanese_radish%d.png", tyear), bg="white", width=297*zoom, height=210*zoom)
adj <- 0.18

# TeX等でEPSファイルを使う場合
# postscript(file=sprintf("japanese_radish%d.eps", tyear), width=8, height=6, paper="special", family="Japan1HeiMin", horizontal=FALSE)
# adj <- 0.17

# 余白を設定
par(mai = c(1, 1, 0.75, 1))

# 棒グラフを作成
#  縦横軸は表示しない
barplot(df09$出荷量, df09$年, col="gray", border="black", axes=FALSE, ylim=c(0, 1.1*max(df09$出荷量)), density=15, angle=120, space=0, names.arg=paste(df09$月, "月", sep="\n"), main=sprintf("だいこんの出荷量と価格(%d年)",tyear))

# 左縦軸を表示
#  日本語表記に修正
axis(2, labels=c("0","2万5千トン","5万トン","7万5千トン","10万トン"), at=c(0,25000,50000,75000,100000))

# 余白を再設定
#  new=Tで上書きモード。余白は棒グラフにあわせて調整
par(new=T, mai = c(1 - adj, 1, 0.75, 1))

# 線グラフを作成
#  表示開始・終了データを±0.5することで棒グラフに表示をあわせている
plot(価格 ~ 月, data=df09, type="l", ylim=c(0, floor(1.1*max(df09$価格))), axes=FALSE, ylab="", xlab="", col="blue", lwd=2, xlim=c(min(df09$月)-0.5, max(df09$月)+0.5))

# 右縦軸を表示
price_at <- c(0, 25, 50, 75, 100, 125)
price_label <- sprintf("%d円/Kg", price_at)
price_label[1] <- "0"
axis(side=4, labels=price_label, at=price_at, ylim=c(0, max(df$価格), col="blue", lwd=2, col.ticks="blue"))

# 凡例表示
# (x,y)座標がグラフの目盛と対応している
legend(1, 120, c("出荷量"), col = c("black"), text.col = "black", lty = c(-1), fill=c("gray"), density=c(25), angle=c(120), bg = 'transparent', box.col = 'transparent')
legend(1, 112, c("価格"), col = "blue", text.col = "blue", lty = 1, bg = 'transparent', box.col = 'transparent', lwd=c(2))

# 出所を表示
mtext("出所) 農林水産省ウェブページ - 青果物卸売市場調査", cex=1, side=1, line=1.5, adj=0)

dev.off()
