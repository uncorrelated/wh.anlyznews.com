# semパッケージを読み出す
library(sem)

# テキスト・ファイルからデータを読み込む
df <- read.table("dataset.txt", header=TRUE, sep="\t", fileEncoding="UTF-8")

# 年次ダミーを作成
month <- factor(df$月)

# 年次ダミーを作成（i年10月から(i+1)年9月までをi年とする）
df["年度"] <- ifelse(df$月>=10,df$年+1,df$年)
year <- factor(df$年度)

# 被説明変数と内生変数と外生変数の推定式
#  係数が需要の価格弾力性をそのまま表すように、変数は対数をとっている
frml <- log(出荷量) ~ log(価格) + month + year

# 操作変数と外生変数を指定
zm <- ~ log(降水量.0) + log(日照時間.3) + month + year

# 二段階最小二乗法で推定
r_tsls <- tsls(frml, zm, data=df)

# 推定結果を表示
summary(r_tsls)

# 弱相関テスト
#  操作変数の変わりに定数 1 を用いて推定し、F検定で有意に差があるかを確認
r_weak_iv <- anova(r_tsls, tsls(log(出荷量) ~ 1 + month + year, zm, data=df))
print(paste("弱相関テスト", r_weak_iv["Pr(>F)"]))

# DWH検定
#  まずOLSで推定し、次にOLSとTSLSで有意に差があるかを確認
#  棄却するとOLS推定量が一致推定量でないと言え、TSLS推定量を採用すべきとなる
r_ols <- lm(frml, data=df) 
h_value <- t(r_tsls$coefficients - r_ols$coefficients) %*% solve(vcov(r_tsls) - vcov(r_ols)) %*% (r_tsls$coefficients - r_ols$coefficients)
p_dwh <- 1 - pchisq(h_value, 1)
print(sprintf("DWH検定 %0.5f", p_dwh))

# 過剰識別検定
#  操作変数の数が多い場合は過剰識別になり、操作変数うちの一つと誤差項の相関が疑われる
r_oi_test <- lm(r_tsls$residuals ~ log(降水量.0) + log(日照時間.3) + month + year, data=df)
p_oit <- 1 - pchisq(summary(r_oi_test)$r.squared*length(r_oi_test$residuals), 1)
print(sprintf("過剰識別検定 %0.5f", p_oit))

# 95%信頼区間の区間推定を行う
interval_estimation <- function(ce, se, pv, df){
	interval <- se*qt(pv, df=df)
	print(sprintf("95%%信頼区間 %0.5f ～ %0.5f",ce+interval, ce-interval))
}
interval_estimation(coefficients(r_tsls)[2], vcov(r_tsls)[,2][2], 0.95, length(residuals(r_tsls))-length(coefficients(r_tsls))+1)
