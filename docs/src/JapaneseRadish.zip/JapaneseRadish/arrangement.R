#
# データファイルを読み込む
#
volume <- read.table("price.txt", header=TRUE, sep="\t", fileEncoding="UTF-8")
rainfall <- read.table("rainfall.txt", header=TRUE, sep="\t", fileEncoding="UTF-8")
temperature <- read.table("temperature.txt", header=TRUE, sep="\t", fileEncoding="UTF-8")
insolation <- read.table("insolation.txt", header=TRUE, sep="\t", fileEncoding="UTF-8")

#
# t期 t-1期 t-2期 t-3期... とデータを並べるレイアウト調整関数
#
layout <- function(df, label, s, e, n){
	year <- c()
	month <- c()
	value <- c()
	for(y in s:e){
		s <- subset(df, 年==y)
		for(m in 1:12){
			year <- c(year, y)
			month <- c(month, m)
			value <- c(value, as.numeric(s[sprintf("X%d月", m)]))
		}
	}
	r <- data.frame(year=year, month=month)
	r[sprintf("%s.%d", label, 0)] = value
	for(i in 1:n){
		value <- c(0, value[1:length(value)-1])
		name <- sprintf("%s.%d", label, i)
		r[name] <- value
	}
	return(r)
}

#
# 降水量、気温、日照時間とレイアウトを調整
#
r <- layout(subset(rainfall, block_name=="千葉"), "降水量", 2000, 2010, 3)
t <- layout(subset(temperature, block_name=="千葉"), "気温", 2000, 2010, 3)
i <- layout(subset(insolation, block_name=="千葉"), "日照時間", 2000, 2010, 3)

#
# 年と月をキーに結合
#
tc <- "ID_FOR_JOIN"
r[tc] <- paste(r$year, r$month)
t[tc] <- paste(t$year, t$month)
i[tc] <- paste(i$year, i$month)
volume[tc] <- paste(volume$年, volume$月)
df <- merge(volume, r, by=tc, suffixes=c("",".rf"))
df <- merge(df, t, by=tc, suffixes=c("",".tm"))
df <- merge(df, i, by=tc, suffixes=c("",".in"))

#
# 余分な列を削除（残す列だけ指定）
#
df <- df[c("年", "月","出荷量","価格","降水量.0","降水量.1","降水量.2","降水量.3","気温.0","気温.1","気温.2","気温.3","日照時間.0","日照時間.1","日照時間.2","日照時間.3")]

#
# 年月でソートする
#
df <- df[order(sprintf("%04d%02d",df$年,df$月)),]

#
# ファイルに書き出す
#
write.table(df, file="dataset.txt", sep="\t", row.names=FALSE, fileEncoding="UTF-8")
