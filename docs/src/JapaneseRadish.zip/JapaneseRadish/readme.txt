だいこん出荷量・価格分析スクリプト

だいこん出荷量（需要・供給）と価格を分析するデータとスクリプトのセットです。ファイル構成はイカのようになっています

1. price.txtが価格データです。農林水産省ウェブページの青果物卸売市場調査から作成しました。

2. jma.plとjma.lstは気象庁から気温、降水量、日照時間のデータをダウンロードしてくるPerl ScriptとURLの一覧です。temperature.txt、rainfall.txt、insolation.txtを作成します。

3. arrangement.R は、price.txt、temperature.txt、rainfall.txt、insolation.txtを合成して、dataset.txtを作成するRスクリプトです。

4. analyzation.R はdataset.txtを読み込み、TSLSと一連の検定を行うRスクリプトです。
